package com.emit.promedio

class Clase(
    var nombre: String,
    var nota: Double
) {

}