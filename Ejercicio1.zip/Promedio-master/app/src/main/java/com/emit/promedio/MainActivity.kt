package com.emit.promedio

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.emit.promedio.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    private var classList: MutableList<Clase> = arrayListOf()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)

        with(binding){
            btnSave.setOnClickListener{
                classList.add(Clase(editTextClass.text.toString(), editTexyGrade.text.toString().toDouble()))
            }

            btnProm.setOnClickListener(){
                var i: Int = 0
                if(classList.size == 7){
                   val promedio = classList.map {
                        it.nota
                   }.average()

                    Toast.makeText(this@MainActivity, "${promedio.toString()}", Toast.LENGTH_SHORT).show()
                }
            }
        }


        setContentView(binding.root)
    }
}